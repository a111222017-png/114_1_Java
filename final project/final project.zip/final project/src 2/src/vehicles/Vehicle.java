package vehicles;

// 1. 確保有 public abstract class 開頭
public abstract class Vehicle {

    // --- 原本的基本屬性 ---
    protected String licensePlate;
    protected boolean isMember = false;

    // 建構子
    public Vehicle(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setMember(boolean member) {
        this.isMember = member;
    }

    public boolean isMember() {
        return isMember;
    }

    // --- 2. 解決 @Override 錯誤的關鍵 ---
    // 父類別必須先有這個方法，子類別 (Sedan) 才能 @Override
    public boolean needsCharging() {
        return false; // 預設不需要充電
    }

    // 定義抽象方法 (強制 Sedan, Truck 等子類別一定要實作)
    public abstract int getRequiredSpotCount();
    public abstract String getTypeName();


    // --- 3. 新增的月票功能 (必須包在 class 大括號裡面) ---
    private java.time.LocalDateTime monthlyPassExpiry = null;
    private int entryCount = 0;

    public void setMonthlyPass(int days) {
        if (this.monthlyPassExpiry == null || this.monthlyPassExpiry.isBefore(java.time.LocalDateTime.now())) {
            this.monthlyPassExpiry = java.time.LocalDateTime.now().plusDays(days);
        } else {
            this.monthlyPassExpiry = this.monthlyPassExpiry.plusDays(days);
        }
    }

    public void addEntryCount() {
        this.entryCount++;
    }

    public int getEntryCount() {
        return this.entryCount;
    }

    public boolean isMonthlyMember() {
        return this.monthlyPassExpiry != null && this.monthlyPassExpiry.isAfter(java.time.LocalDateTime.now());
    }

    public long getRemainingDays() {
        if (!isMonthlyMember()) {
            return -1;
        }
        return java.time.Duration.between(java.time.LocalDateTime.now(), this.monthlyPassExpiry).toDays();
    }

} // <--- 4. 這一行大括號絕對不能少！