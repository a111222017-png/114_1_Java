import java.io.PrintStream;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import spots.ElectricSpot;
import spots.ParkingFloor;
import spots.ParkingSpot;
import spots.RegularSpot;
import spots.SmallSpot;
import strategies.MemberPricingStrategy;
import strategies.TimeBasedPricingStrategy;
import system.ParkingLot;
import system.ParkingTicket;
import vehicles.ElectricVehicle;
import vehicles.Motorcycle;
import vehicles.Sedan;
import vehicles.Truck;
import vehicles.Vehicle;

public class Main {
    private static Map<String, ParkingTicket> activeTickets = new HashMap();
    private static Scanner scanner = new Scanner(System.in);

    // 顯示費率資訊 (保持不變)
    private static void showPricingInfo() {
        TimeBasedPricingStrategy timeStrategy = new TimeBasedPricingStrategy();
        System.out.println("--------------------------------");
        System.out.println("=== 費率說明 (時段差別費率) ===");
        System.out.println("  [平日] 日間: 40元/hr, 夜間: 20元/hr");
        System.out.println("  [假日] 全天: 50元/hr");
        System.out.println("  * 月票會員享有無限次進1出資格 (需先申請)");
        System.out.println("=== 智慧停車場管理系統 (正式版) ===");
        System.out.flush();
    }

    // 修改：新增選項 4
    private static void showMenu() {
        System.out.println("\n請選擇功能:");
        System.out.println("1. 車輛進場 (Entry)");
        System.out.println("2. 車輛離場 (Exit)");
        System.out.println("3. 查詢場內車輛 (Status)");
        System.out.println("4. 查詢月票狀態 (Member Info)");
        System.out.println("0. 結束系統 (Quit)");
        System.out.print("輸入選項: ");
        System.out.flush();
    }

    public static void main(String[] var0) {
        ParkingLot var1 = initializeParkingLot();
        System.out.println("系統初始化完成，等待指令...");
        showPricingInfo();

        while(true) {
            try {
                showMenu();
                String userInput = scanner.nextLine();
                switch (userInput) {
                    case "1":
                        handleEntryProcess(var1);
                        break;
                    case "2":
                        handleExitProcess(var1);
                        break;
                    case "3":
                        showStatus();
                        break;
                    case "4":
                        // 新增功能呼叫
                        checkMemberStatus();
                        break;
                    case "0":
                        System.out.println("系統已關閉。");
                        return;
                    default:
                        System.out.println("無效的選項，請重新輸入。");
                }
            } catch (Exception var5) {
                // 這裡會捕捉到我們丟出的「非會員」錯誤訊息並印出
                System.err.println("錯誤提示: " + var5.getMessage());
            }
        }
    }

    // 初始化停車場 (保持不變)
    private static ParkingLot initializeParkingLot() {
        ParkingLot var0 = new ParkingLot();
        ParkingFloor var1 = new ParkingFloor(1);
        for(int var2 = 1; var2 <= 5; ++var2) { var1.addSpot(new SmallSpot(var2, 1)); }
        for(int var4 = 6; var4 <= 15; ++var4) { var1.addSpot(new RegularSpot(var4, 1)); }
        for(int var5 = 16; var5 <= 18; ++var5) { var1.addSpot(new ElectricSpot(var5, 1)); }
        ParkingFloor var6 = new ParkingFloor(2);
        for(int var3 = 1; var3 <= 20; ++var3) { var6.addSpot(new RegularSpot(200 + var3, 2)); }
        var0.addFloor(var1);
        var0.addFloor(var6);
        return var0;
    }

    // 修改：進場流程 (增加月票設定與次數累計)
    private static void handleEntryProcess(ParkingLot var0) {
        System.out.println("\n[車輛進場]");
        System.out.print("請輸入車牌號碼: ");
        String var1 = scanner.nextLine().trim();
        if (activeTickets.containsKey(var1)) {
            System.out.println("錯誤：該車輛已經在停車場內！");
        } else {
            System.out.println("選擇車種: 1.轎車 2.貨車 3.機車 4.電動車");
            System.out.print("輸入選項: ");
            String var2 = scanner.nextLine();
            Vehicle var3 = null; // 改成 Vehicle 型態以便呼叫新方法

            try {
                switch (var2) {
                    case "1": var3 = new Sedan(var1); break;
                    case "2": var3 = new Truck(var1); break;
                    case "3": var3 = new Motorcycle(var1); break;
                    case "4":
                        System.out.print("是否需要充電? (y/n): ");
                        boolean var6 = scanner.nextLine().trim().equalsIgnoreCase("y");
                        var3 = new ElectricVehicle(var1, var6);
                        break;
                    default:
                        System.out.println("無效的車種。");
                        return;
                }

                // --- 新增：模擬購買月票 ---
                System.out.print("是否申請/展延月票 (30天)? (y/n): ");
                if (scanner.nextLine().trim().equalsIgnoreCase("y")) {
                    var3.setMonthlyPass(30); // 設定 30 天月票
                    var3.setMember(true);    // 設定為一般會員標記
                    System.out.println(">>> 已開通月票資格 (30天)");
                }

                // --- 新增：累積進場次數 ---
                var3.addEntryCount();

                ParkingTicket var4 = var0.handleEntry(var3);
                activeTickets.put(var1, var4);

                System.out.println(">>> 進場成功!");
                // 顯示是否為月票進場
                if (var3.isMonthlyMember()) {
                    System.out.println("(以月票身分進場，本次不計時收費)");
                }

                System.out.print("分配車位: ");
                for(ParkingSpot var11 : var4.getAllocatedSpots()) {
                    System.out.print(var11.getFloor() + "樓-" + var11.getId() + "號 ");
                }
                System.out.println();
            } catch (Exception var8) {
                System.out.println("進場失敗: " + var8.getMessage());
            }
        }
    }

    // 離場流程 (保持不變)
    private static void handleExitProcess(ParkingLot var0) {
        System.out.println("\n[車輛離場]");
        System.out.print("請輸入車牌號碼: ");
        String var1 = scanner.nextLine().trim();
        if (!activeTickets.containsKey(var1)) {
            System.out.println("錯誤：找不到此車牌的進場紀錄。");
        } else {
            ParkingTicket ticket = activeTickets.get(var1);

            // 若是月票會員，直接離場不需輸入模擬時間 (或顯示 0 元)
            if (ticket.getVehicle().isMonthlyMember()) {
                System.out.println("偵測到月票會員，免過卡扣款。");
                activeTickets.remove(var1);
                System.out.println(">>> 離場成功 (月票)");
                System.out.println("本期累積進出次數: " + ticket.getVehicle().getEntryCount() + " 次");
                return;
            }

            // 一般離場流程
            System.out.print("模擬停車時數 (小時): ");
            try {
                double hours = Double.parseDouble(scanner.nextLine());
                long durationMinutes = (long)(hours * 60.0);
                LocalDateTime exitTime = LocalDateTime.now().plusMinutes(durationMinutes);
                ticket.setExitTime(exitTime);

                boolean isCharging = false;
                Duration chargeDuration = Duration.ZERO;
                if (ticket.getVehicle().needsCharging()) {
                    System.out.print("是否有進行充電? (y/n): ");
                    if (scanner.nextLine().trim().equalsIgnoreCase("y")) {
                        isCharging = true;
                        System.out.print("模擬充電時長 (分鐘): ");
                        long mins = Long.parseLong(scanner.nextLine());
                        chargeDuration = Duration.ofMinutes(mins);
                    }
                }

                // 呼叫包含時間策略的計算
                // double finalCost = var0.handleExit(ticket, isCharging, chargeDuration);
                // 為了相容你的程式碼，這裡保留原本的呼叫方式，請確保 handleExit 內使用了新的 TimeStrategy
                double finalCost = var0.handleExit(ticket, isCharging, chargeDuration);

                activeTickets.remove(var1);
                System.out.println(">>> 離場成功!");
                System.out.println("應付費用: " + finalCost + " 元");

            } catch (Exception var14) {
                System.out.println("離場失敗: " + var14.getMessage());
            }
        }
    }

    private static void showStatus() {
        System.out.println("\n[查詢場內車輛]");
        if (activeTickets.isEmpty()) {
            System.out.println("目前沒有車輛在停車場內。");
        } else {
            for(ParkingTicket var1 : activeTickets.values()) {
                System.out.println("車牌: " + var1.getVehicle().getLicensePlate() +
                        " | 月票: " + (var1.getVehicle().isMonthlyMember() ? "是" : "否"));
            }
        }
    }

    // --- 新增的功能方法 ---
    private static void checkMemberStatus() throws Exception {
        System.out.println("\n[查詢月票會員狀態]");
        System.out.print("請輸入要查詢的車牌號碼: ");
        String plate = scanner.nextLine().trim();

        // 注意：這個範例只能查詢「目前在場內」的車子
        // 若要查詢不在場內的，需要另外建立一個 Map<String, Vehicle> memberDatabase 來儲存所有會員資料
        if (!activeTickets.containsKey(plate)) {
            throw new Exception("查無此車輛在場內資料 (本系統僅能查詢已進場車輛)");
        }

        Vehicle vehicle = activeTickets.get(plate).getVehicle();

        // 核心邏輯：如果沒有月票資格，直接拋出例外
        if (!vehicle.isMonthlyMember()) {
            // 這裡滿足你的需求：如果沒有會員的要報錯
            throw new Exception("錯誤：車輛 " + plate + " 並非月票會員！");
        }

        // 若是會員，顯示詳細資訊
        System.out.println(">>> 會員查詢結果");
        System.out.println("車牌號碼: " + vehicle.getLicensePlate());
        System.out.println("會員資格: 有效 (月票)");
        System.out.println("剩餘天數: " + vehicle.getRemainingDays() + " 天");
        System.out.println("累計進出: " + vehicle.getEntryCount() + " 次");
        System.out.println("-------------------------");
    }
}