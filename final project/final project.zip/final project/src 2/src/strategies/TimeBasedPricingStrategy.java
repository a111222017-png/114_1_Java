package strategies;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Duration;

public class TimeBasedPricingStrategy {

    // 費率設定 (元/小時)
    private static final double RATE_WEEKDAY_DAY = 40.0;   // 平日白天
    private static final double RATE_WEEKDAY_NIGHT = 20.0; // 平日晚上
    private static final double RATE_WEEKEND = 50.0;       // 假日全天

    // 日間時段定義 (早上8點 到 晚上8點)
    private static final int DAY_START_HOUR = 8;
    private static final int DAY_END_HOUR = 20;

    /**
     * 計算停車費用的核心方法
     * @param entryTime 進場時間
     * @param exitTime  離場時間
     * @return 總費用
     */
    public double calculate(LocalDateTime entryTime, LocalDateTime exitTime) {
        double totalCost = 0.0;

        // 為了計算精準且處理跨日/跨時段，我們將時間切分為「分鐘」來計算
        // 複製一份進場時間作為計算游標
        LocalDateTime currentCursor = entryTime;

        // 當 計算游標 還沒到達 離場時間 時，持續迴圈
        while (currentCursor.isBefore(exitTime)) {
            // 取得當下的費率 (每分鐘價格)
            double ratePerMinute = getRateForTime(currentCursor) / 60.0;

            // 累加費用
            totalCost += ratePerMinute;

            // 時間往前推 1 分鐘
            currentCursor = currentCursor.plusMinutes(1);
        }

        return Math.round(totalCost); // 四雪五入回傳整數金額
    }

    /**
     * 判斷某個特定時間點的費率是多少
     */
    private double getRateForTime(LocalDateTime time) {
        DayOfWeek day = time.getDayOfWeek();
        int hour = time.getHour();

        // 判斷是否為假日 (週六 或 週日)
        boolean isWeekend = (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY);

        if (isWeekend) {
            return RATE_WEEKEND;
        } else {
            // 平日：判斷是日間還是夜間
            if (hour >= DAY_START_HOUR && hour < DAY_END_HOUR) {
                return RATE_WEEKDAY_DAY;
            } else {
                return RATE_WEEKDAY_NIGHT;
            }
        }
    }
}